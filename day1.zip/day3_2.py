#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
from pandas import Series, DataFrame
import matplotlib.pyplot as plt
import seaborn as sns



# ## series 생성, 조회

# In[2]:


arr1 = np.random.randn(4)
arr1


# In[3]:


ser1 = Series(arr1)


# In[4]:


ser1


# In[12]:


ser1 = Series(arr1, index = list('abcc'))


# In[13]:


ser1.index


# In[14]:


ser1.values


# In[15]:


ser1['c']


# In[16]:


print(ser1['c'])


# In[17]:


ser1['c']=100
print(ser1)


# In[18]:


ser1[0:3]  # 끝값 포함안됨


# In[19]:


ser1['a':'b']  # 끝값 포함됨


# In[21]:


#ser1['a','c']## error
ser1[['a','c']]  


# In[22]:


ser1[ser1>0]


# In[23]:


ser1*3


# In[53]:


data = {2001:1.5, 2002:1.6, 2003:1.8}
data2 = {'c':1.5, 'd':1.6, 'e':1.8}


# In[54]:


ser2 = Series(data)
ser3 = Series(data2)


# In[55]:


ser2


# In[31]:


#x = np.array(ser2)


# In[56]:


ser2+ser3


# In[51]:


ser1.index.name = 'gubun'

print(ser1)


# In[45]:


ser1.plot(kind='barh')
plt.show()


# In[ ]:




