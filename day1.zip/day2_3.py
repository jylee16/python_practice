#!/usr/bin/env python
# coding: utf-8

# In[4]:


import numpy as np

arr1 = np.array([[1,2],[3,4]])


# In[5]:


import pandas as pd
from pandas import Series, DataFrame

df2 = DataFrame(arr1)


# In[6]:


df2


# In[2]:


import smartTV as st
import phone as ph    # load 시 한번만 실행


# In[3]:



print(__name__)
if __name__ =='__main__':
    ph.call('123124')


# In[6]:


import empModule 

person=[]
for idx in range(0,2):
    info= input('input(이름,부서,연봉,주당근무시간): ').split(',')   
    #info = [int(x) if x.isnumeric() else x for x in info]
    ins = empModule.Employee(info[0],info[1],info[2],info[3])
    ins.showEmpInfo()
    person.append(ins)


paysum =0

for i in person:
    paysum = paysum +i.payForWeek()

print('total:', paysum)


# In[11]:


f = None
try:
    f = open('result.txt','rt')
    res = f.readlines()
    
    for i in res:
        print(i)

except FileNotFoundError as e:
    print("error",e)

finally:
    if f!=None:
        f.close()




# In[1]:



import empModule 

f = None

person=[]
try:
    f = open('empinfo.txt','rt')
    res = f.readlines()
    
    for i in res:
        info= i.split(',')
        ins = empModule.Employee(info[0],info[1],info[2],info[3])
        ins.showEmpInfo()
        person.append(ins)
        
except FileNotFoundError as e:
    print("error",e)

paysum =0
max_pay=0
idx =0
name=''
for i in person:
    #i.split(':')
    paysum = paysum +i.payForWeek()
    if(max_pay<i.payForWeek()):
        name =i.getName()

print('total:', paysum)
print('가장많이 받은 사람:', name)


# In[7]:


import numpy as np
a=list(range(0,10))


# In[8]:


print(a)


# In[9]:


arr2 = np.array(a)


# In[10]:


print(arr2)


# In[15]:


b=[[1,2],[3,4],[5,6]]


# In[16]:


print(b)


# In[17]:


c = np.array(b)


# In[18]:


print(c)


# In[19]:


print(b)


# In[20]:


b[2][1]


# In[21]:


c[2][1]


# In[22]:


b.append([7,8])
print(b)


# In[24]:


np.append(b,[6,7])


# In[25]:


print(b)


# In[26]:


test = np.array([[1,2,3],[4,5,6],[7,8,9]])


# In[27]:


print(test)


# In[32]:


print(np.sum(test,axis=0))


# In[31]:


print(test.sum(axis=1))


# In[38]:


print(test[1,:]) # rank1 정수형 index slcing
print(test[1][:])


# In[39]:


print(test[1:2,:]) # rank2 범위로 indexing => 2차원


# In[40]:


print(test[:,0])


# In[41]:


print(test[:,0:1])


# In[42]:


sliced_data = test[1:2,:] 


# In[43]:


print(sliced_data)   # 단순복사


# In[44]:


sliced_data[:] = 10 


# In[45]:


print(sliced_data)


# In[46]:


print(test)  # 원본이 변경됨(단순복사)


# In[52]:


import copy

a = [1, [1, 2, 3]]
b = copy.copy(a)    # shallow copy 발생
print(b)    # [1, [1, 2, 3]] 출력
b[0] = 100
print(b)    # [100, [1, 2, 3]] 출력,
print(a)    # [1, [1, 2, 3]] 출력, shallow copy 가 발생해 복사된 리스트는 별도의 객체이므로 item을 수정하면 복사본만 수정된다. (immutable 객체의 경우)

c = copy.copy(a)
c[1].append(4)    # 리스트의 두번째 item(내부리스트)에 4를 추가
print(c)    # [1, [1, 2, 3, 4]] 출력
print(a)    # [1, [1, 2, 3, 4]] 출력

c[1][2]=100
print(c)
print(a)
c.append(500)
print(c)
print(a)


# In[ ]:




