
val = input("intput:")

try:
    if val == 'a'
        print('alpha')
    elif val =='b':
        print('bravo')
    elif val =='c':
        print('chaile')
    else
        raise ValueError()
except ValueError as e:
    print('받아들일수없는 문자',val,'가 입력되었습니다')
