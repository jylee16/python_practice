#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
from pandas import Series, DataFrame
import matplotlib.pyplot as plt
import seaborn as sns



# In[7]:


data = {'city':['seoul','Daegu','Pusan'],'pop':[1.8,1.4,1.1],'info':['large','med','smal']}

df1 = DataFrame(data, index = ['one','two','three'])
#df1 = DataFrame(data)
df1


# In[115]:


df1['city']

type(df1)


# In[29]:


df1


# In[31]:


# df1['two'] index로 는 못가져옴

df1.columns
df2 = df1.rename(columns ={df1.columns[1]:'pop'} )
df2


# In[34]:


df1.rename(columns ={df1.columns[1]:'pop'} , inplace = True)  # inpace = true 조건: 원본에 값변경 반영


# In[35]:


df1['info'] = np.nan


# In[37]:


df1['info'] = np.random.randn(3)


# In[44]:


df1.T # trnaspose


# In[45]:


df3 = df1.T


# In[46]:


df3


# In[49]:


df3[0]


# In[50]:


df1.index.name = 'gubun'
df1.columns.name = 'cityinfo'


# In[54]:


df1

#삭제
del df1['info']


# In[55]:


df1


# In[58]:


df4 = DataFrame(np.random.randn(4,5), columns= list('abcde'))
df4


# In[66]:



df5 = pd.read_csv('../data/cars.csv')


# In[71]:


df5.info


# In[73]:


df5.head(2)  # 상위 2개만 확인
df5.tail(3)  # 하위 3개


# In[79]:


df5.sort_values(by= 'MPG', ascending = False)   # MPG  내림차순 sorting


# In[84]:


df5.loc['0':'1']


# In[86]:


df2['info'] = ['large','medium','middle-large']


# In[90]:


df2


# In[108]:


df2.loc[1:2,'city':'pop']


# In[110]:


df2.at[1,'city']  # scalar 값 하나 가져올때는 가장 빠름


# In[11]:



df1.loc['one':'three',['pop','info']]
df1.loc['one':'three','pop':'info']

df1.iloc[0:2, 1:2]  # 끝값 포함안함 (정수형 인덱싱)


# In[12]:


df1['pop']


# In[21]:


sub1 = df1.iloc[:,1]   # series
sub1


# In[18]:


sub2 = df1.iloc[:,1:2]  #dataframe
sub2


# In[44]:


df7 = DataFrame(np.random.randn(4,4), index = list('abcd'),columns = list('fghi'))
df7


# In[45]:


bb ='asdf'


# In[46]:


bb[2]


# In[47]:


cc = list('asdf')


# In[48]:


cc[2]


# In[55]:


df7.loc['c','f']=np.nan
#df7.isna()
df7.isna().sum(axis=1)
df7.iat[2,3]=np.nan


# In[58]:


df7.iloc[1,:]= np.nan

df7


# In[66]:


#df7.dropna()
#df7.dropna(how='all')
df7.dropna(thresh=3)


# In[67]:


df8 = df7.fillna(df7.mean(), inplace = True)


# In[69]:


print(df7.mean())


# In[83]:


studentlist = pd.read_csv('../data/studentlist.csv',encoding ='euc-kr')


# In[111]:


#studentlist.head(3)

stu_ab = studentlist[studentlist["혈액형"] =='AB']
stu_o = studentlist[studentlist["혈액형"] =='O']


# In[112]:


stu_ab
stu_o


# In[113]:


studf_abo = pd.concat([stu_ab,stu_o])


# In[114]:


studf_abo


# In[115]:


studf_abo.drop(['성별','몸무게'], axis = 1, inplace = True)


# In[ ]:





# In[116]:


studf_abo.rename(columns = {studf_abo.columns[6]:'시력'}, inplace=True)


# In[110]:


studf_abo


# In[119]:


res = pd.merge(studentlist, studf_abo, on='이름')  ## 시력만 추가 (교집합추가)
res = pd.merge(studentlist, studf_abo, on='이름', how='outer')  ## 시력만 추가 (교집합추가)


# In[120]:


res


# In[ ]:




