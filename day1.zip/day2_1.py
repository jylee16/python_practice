#!/usr/bin/env python
# coding: utf-8

# In[2]:





a =1
var1 = locals()

dir(__builtin__)



# In[16]:


import random
a=['a',1,2,4,5]

random.shuffle(a)

print(a)


# In[8]:


class Person:
    
    info = "NA"
    
    # 생성자
    def __init__(self, name, age, addr):
        self.name = name
        self.age = age
        self.addr = addr
    
    def showinfo(self):
        print("이름 %s 나이 %d, 주소 %s" %(self.name,self.age,self.addr))
    
    


# In[9]:


person = Person("john", 55, '서울')


# In[10]:


person.showinfo()


# In[11]:


import numpy as np
import pandas as pd
from pandas import DataFrame

df = DataFrame(np.random.randn(4,4),columns = list('ABCD'))
df


# In[ ]:




