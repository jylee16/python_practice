#!/usr/bin/env python
# coding: utf-8

# # 서울시 구별 CCTV 현황 분석하기
# 

# In[1]:


import pandas as pd


# In[5]:


#다운로드 받은 01. CCTV_in_Seoul.csv 파일을 읽으세요. encoding='utf-8' 로 읽으세요. 

CCTV_Seoul = pd.read_csv('../data/01. CCTV_in_Seoul.csv',encoding ='utf-8')
CCTV_Seoul.head()


# In[7]:


# 컬럼 정보를 읽으세요. 
CCTV_Seoul.columns
    


# In[8]:


CCTV_Seoul.columns[0]


# In[12]:


#CCTV_Seoul.columns[0] 번째 정보를 '구별' 이라는 이름으로 바꾸세요. 
CCTV_Seoul.rename(columns = {CCTV_Seoul.columns[0]:'구별'}, inplace=True)

CCTV_Seoul


# ## 2-2. 엑셀파일 읽기 - 서울시 인구현황

# In[123]:


# 01. population_in_Seoul.xls 엑셀 파일을 읽으세요. pip install xlrd 설치가 필요함 




# In[124]:


# 01. population_in_Seoul.xls 서울의 인구수에 대한 파일을 읽으세요. 
# usecols = 'B, D, G, J, N' 옵션을 사용하여 해당 컬럼만 읽어 들이세요. 

POP_Seoul = pd.read_excel('../data/01. population_in_Seoul.xls', header = 2 ,usecols="B ,D, G, J, N" )  #header =2 부터 시작하겠다
POP_Seoul    


# In[125]:


# 각컬럼명을 '구별' '인구수', '한국인', '외국인', '고령자' 로 바꾸세요. 
POP_Seoul.rename(columns = {POP_Seoul.columns[0]:'구별',
                            POP_Seoul.columns[1]:'인구수',
                            POP_Seoul.columns[2]:'한국인',
                            POP_Seoul.columns[3]:'외국인'}, inplace=True)
# POP_Seoul.rename(columns = {POP_Seoul.columns[0]:'구별'}, inplace=True)
# POP_Seoul.rename(columns = {POP_Seoul.columns[1]:'인구수'}, inplace=True)
# POP_Seoul.rename(columns = {POP_Seoul.columns[2]:'한국인'}, inplace=True)
# POP_Seoul.rename(columns = {POP_Seoul.columns[3]:'외국인'}, inplace=True)
POP_Seoul    


# # 3. CCTV 데이터 파악하기

# In[126]:


CCTV_Seoul.head()


# In[127]:


#'소계'로 오름차순 정렬하여 앞에서부터 5개만 보여주세요. 
sub1= CCTV_Seoul.sort_values('소계',ascending=False).head(5)
sub1


# In[128]:


#'소계'로 내림차순 정렬하여 앞에서부터 5개만 보여주세요. 
#'소계'로 오름차순 정렬하여 앞에서부터 5개만 보여주세요. 
sub2= CCTV_Seoul.sort_values('소계',ascending=True).head(5)
sub2
 


# In[129]:


# '최근증가율' 컬럼에  (2016년도컬럼 + 2015년도컬럼 + 2014년도컬럼 )/ 2013년도 이전  * 100 으로 계산하여 채우세요.

total_sum = CCTV_Seoul['2016년']+CCTV_Seoul['2015년']+CCTV_Seoul['2014년']

diff = (total_sum/CCTV_Seoul['2013년도 이전'])*100

CCTV_Seoul['최근증가율'] = diff

CCTV_Seoul.sort_values(by = '최근증가율',ascending=False).head(5)


# 최근증가율 컬럼으로 내림차순 정렬하여 앞에서부터 5개만 보여주세요. 
 
    


# # 5. 서울시 인구 데이터 파악하기

# In[130]:


POP_Seoul.head(5)


# In[131]:


# 위의 데이터중 첫번째 행을 지우세요. 합계정보는 필요없습니다. 
POP_Seoul.drop([0], inplace=True) # defulat axis = 0
 
    


# In[132]:


# '구별' 정보에서 unique() 함수를 사용하여 유니크한 값만 뽑으세요. 
 
POP_Seoul['구별'].unique()
    


# In[133]:


#pop_Seoul에 '구별' 정보가 null 인지 체크하세요. isnull() 함수 사용 
#POP_Seoul['구별'].isnull()
POP_Seoul[POP_Seoul['구별'].isnull()]


# In[134]:


# 위에서 찾은 26번째 행을 지우세요. 

POP_Seoul.drop([26],inplace=True)
 
    


# In[135]:


# '고령자비율' 컬럼 = 고령자컬럼 / 인구수 컬럼 * 100 
# '외국인비율' 컬럼 = 외국인컬럼 / 인구수 컬럼 * 100

#sub = POP_Seoul.drop([0,1,28])

ratio_senior = 100*POP_Seoul['65세이상고령자']/POP_Seoul['인구수']
ratio_foreiner = 100*POP_Seoul['외국인']/POP_Seoul['인구수']


POP_Seoul['외국인비율'] = ratio_foreiner
POP_Seoul['고령자비율'] = ratio_senior
POP_Seoul


# In[136]:


# '인구수'로 내림차순 정렬하여 앞에서부터 5개만 보여주세요. 



POP_Seoul.sort_values('인구수',ascending=False).head(5)


# In[137]:


# '외국인' 으로 내림차순 정렬하여 앞에서부터 5개만 보여주세요.
POP_Seoul.sort_values('외국인',ascending=False).head(5)
 
    


# In[138]:


# '외국인비율' 로 내림차순 정렬하여 5개만 보여주세요. 

POP_Seoul.sort_values('외국인비율',ascending=False).head(5)


# In[139]:


# '고령자' 로 내림차순 정렬하여 앞에서 부터 5개만 보여주세요. 

POP_Seoul.sort_values('65세이상고령자',ascending=False).head(5)


# In[140]:


#고령자비율 컬럼으로 내림차순 정렬하여 5개만 보여주세요. 

POP_Seoul.sort_values('고령자비율',ascending=False).head(5)
    


# In[ ]:




