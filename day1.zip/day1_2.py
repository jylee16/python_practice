#!/usr/bin/env python
# coding: utf-8

# In[1]:


a=3

if a%2==0:
    print('짝수')
else:
    print('홀수')


# In[9]:


ml = range(1,3)
print(ml)

for i in ml:
    print(i)
    
mml = list(range(1,3))
print(mml)

for k in range(len(ml)):
    print(ml[k])


# In[34]:


val = int(input('input:'))


res = 0
for i in range(1,val+1):
    if(i%2 != 0)&(i%3 != 0)  :
        res = res+i
print(res)


for i in range(1,val+1):
    if((i%2 == 0) | (i%3 == 0)):
        continue   
    res = res+i
print(res)


# In[60]:


val= input('input:')

val = val.split(',')
val.sort() #sol1
val = [int(x) for x in val]
res = 0

if(val[0]>val[1]):  # sol2
    val[0],val[1] = val[1],val[0]

for i in range(min(val),max(val)+1): #sol3
    print(i)
    res = res+i
print(res)


# In[62]:


aa=[1,3,2,4,5]

aa=['짝' if x %2 ==0 else '홀' for x in aa]
print(aa)


# In[71]:


max1=[[1,2,3],[4,5,6],[7,8,9,10]]

for i in range(len(max1)):
    temp=max1[i]
    for j in range(len(temp)):
        print(temp[j],'\t' ,end="")
    print('\n')
    
for i in max1:
    for j in i:
        print(j,'\t',end='')
    print()


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




