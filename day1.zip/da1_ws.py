#!/usr/bin/env python
# coding: utf-8

# In[1]:


## 1번


# In[3]:


mylist = [[1,2,3,4,5]]

mylist[0].append(77)

print(mylist)


# In[4]:


## 2번


# In[22]:


score={'철수':'95', '영희':'88','길동':'92'}

score['수지']='98'

print(score)
del score['길동']
print(score)


# In[12]:


## 3번


# In[16]:


mylist = [1,2,3,5,3,2,9,8,11,7,5,1]

res=set(mylist)
print(list(res))


# In[17]:


## 4번


# In[21]:


LIST =[ "Python is simple","apple is delicious","programming"]

print(list (set(LIST[0]) & set(LIST[1]) & set(LIST[2]) ))


# In[33]:


## 5번
res = 0
for i in range(1,11):
    for j in range(1,i+1):
        res = res+j
print(res)


# In[34]:


##6번


# In[ ]:


import random


num = random.randrange(1,100)

cnt =1;
while (True):
    val = int(input('input:'))
    if num == val:
        print('정답입니다', str(cnt), '번에 맞혔습니다')
        break 
    elif num> val:
        print('작습니다 더 큰 숫자를 입력하세요')
    else:
        print('큽니다 더 작은 숫자를 입력하세요')


        


# # 7번

# In[4]:


months = ["January", "February", "March", "April", "May", "June", "July", "August","Septemeber", "October", "November", "December"]

data =[]
for month in months:
    data.append(month[0:3])
print(data)


# In[5]:


##8번


# In[5]:


import random


def makeLotto(num):

    result =[]

    #print(type(numberset))
    for game in range(0,num):
        print(game)
        numberset=set()
        while(True):
            numberset.add(random.randrange(1,45))
            if(len(numberset)==6):
                break
        result.append(list(numberset))
    return result

makeLotto(2)

    


# In[ ]:




