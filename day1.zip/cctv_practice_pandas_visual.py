#!/usr/bin/env python
# coding: utf-8

# # 서울시 구별 CCTV 현황 분석하기
# 

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# In[3]:


#다운로드 받은 01. CCTV_in_Seoul.csv 파일을 읽으세요. encoding='utf-8' 로 읽으세요. 

CCTV_Seoul = pd.read_csv('../data/01. CCTV_in_Seoul.csv',  encoding='utf-8')
CCTV_Seoul.head()


# In[4]:


# 컬럼 정보를 읽으세요. 

CCTV_Seoul.columns


# In[5]:


CCTV_Seoul.columns[0]


# In[6]:


#CCTV_Seoul.columns[0] 번째 정보를 '구별' 이라는 이름으로 바꾸세요. 

CCTV_Seoul.rename(columns={CCTV_Seoul.columns[0] : '구별'}, inplace=True)
CCTV_Seoul.head()


# ## 2-2. 엑셀파일 읽기 - 서울시 인구현황

# In[7]:


# 01. population_in_Seoul.xls 엑셀 파일을 읽으세요. pip install xlrd 설치가 필요함 

pop_Seoul = pd.read_excel('../data/01. population_in_Seoul.xls',  encoding='utf-8')
pop_Seoul.head()


# In[8]:


# 01. population_in_Seoul.xls 서울의 인구수에 대한 파일을 읽으세요. 
# usecols = 'B, D, G, J, N' 옵션을 사용하여 해당 컬럼만 읽어 들이세요. 

pop_Seoul = pd.read_excel('../data/01. population_in_Seoul.xls', 
                          header = 2,
                          usecols = 'B, D, G, J, N',
                          encoding='utf-8')
pop_Seoul.head()


# In[9]:


# 각컬럼명을 '구별' '인구수', '한국인', '외국인', '고령자' 로 바꾸세요. 

pop_Seoul.rename(columns={pop_Seoul.columns[0] : '구별', 
                          pop_Seoul.columns[1] : '인구수', 
                          pop_Seoul.columns[2] : '한국인', 
                          pop_Seoul.columns[3] : '외국인', 
                          pop_Seoul.columns[4] : '고령자'}, inplace=True)
pop_Seoul.head()


# # 3. CCTV 데이터 파악하기

# In[10]:


CCTV_Seoul.head()


# In[11]:


#'소계'로 오름차순 정렬하여 앞에서부터 5개만 보여주세요. 

CCTV_Seoul.sort_values(by='소계', ascending=True).head(5)


# In[12]:


#'소계'로 내림차순 정렬하여 앞에서부터 5개만 보여주세요. 

CCTV_Seoul.sort_values(by='소계', ascending=False).head(5)


# In[13]:


# '최근증가율' 컬럼에  (2016년도컬럼 + 2015년도컬럼 + 2014년도컬럼 )/ 2013년도 이전  * 100 으로 계산하여 채우세요.

CCTV_Seoul['최근증가율'] = (CCTV_Seoul['2016년'] + CCTV_Seoul['2015년'] +                         CCTV_Seoul['2014년']) / CCTV_Seoul['2013년도 이전']  * 100

# 최근증가율 컬럼으로 내림차순 정렬하여 앞에서부터 5개만 보여주세요. 
CCTV_Seoul.sort_values(by='최근증가율', ascending=False).head(5)


# # 5. 서울시 인구 데이터 파악하기

# In[14]:


pop_Seoul.head()


# In[15]:


# 위의 데이터중 첫번째 행을 지우세요. 합계정보는 필요없습니다. 

pop_Seoul.drop([0],axis=0, inplace=True)
pop_Seoul.head()


# In[ ]:





# In[16]:


# '구별' 정보에서 unique() 함수를 사용하여 유니크한 값만 뽑으세요. 

pop_Seoul['구별'].unique()


# In[17]:


#pop_Seoul에 '구별' 정보가 null 인지 체크하세요. isnull() 함수 사용 

pop_Seoul[pop_Seoul['구별'].isnull()]


# In[18]:


# 위에서 찾은 26번째 행을 지우세요. 

pop_Seoul.drop([26], inplace=True)
pop_Seoul.head()


# In[19]:


# '고령자비율' 컬럼 = 고령자컬럼 / 인구수 컬럼 * 100 
# '외국인비율' 컬럼 = 외국인컬럼 / 인구수 컬럼 * 100

pop_Seoul['외국인비율'] = pop_Seoul['외국인'] / pop_Seoul['인구수'] * 100
pop_Seoul['고령자비율'] = pop_Seoul['고령자'] / pop_Seoul['인구수'] * 100
pop_Seoul.head()


# In[20]:


# '인구수'로 내림차순 정렬하여 앞에서부터 5개만 보여주세요. 

pop_Seoul.sort_values(by='인구수', ascending=False).head(5)


# In[21]:


# '외국인' 으로 내림차순 정렬하여 앞에서부터 5개만 보여주세요.

pop_Seoul.sort_values(by='외국인', ascending=False).head(5)


# In[22]:


# '외국인비율' 로 내림차순 정렬하여 5개만 보여주세요. 

pop_Seoul.sort_values(by='외국인비율', ascending=False).head(5)


# In[23]:


# '고령자' 로 내림차순 정렬하여 앞에서 부터 5개만 보여주세요. 

pop_Seoul.sort_values(by='고령자', ascending=False).head(5)


# In[24]:


#고령자비율 컬럼으로 내림차순 정렬하여 5개만 보여주세요. 

pop_Seoul.sort_values(by='고령자비율', ascending=False).head(5)


# # 6. CCTV 데이터와 인구 데이터 합치고 분석하기

# In[100]:


CCTV_Seoul


# In[101]:


pop_Seoul


# # Pandas & 시각화 연습 -----------------------------

# In[105]:


# CCTV_Seoul 데이터프레임과 pop_Seoul 데이터 프레임을 '구별' 정보로 merge 하세요. 
CCTV_Seoul
pop_Seoul
res = pd.merge(CCTV_Seoul,pop_Seoul, on ="구별")
res


# In[108]:


#불필요한 컬럼을 지우세요. '2013년도 이전', '2014년','2015년','2016년' 컬럼 

res.drop(['2013년도 이전', '2014년','2015년','2016년' ], axis = 1, inplace = True) # default 

# del res["2013년도 이전"]
# del res["2014년"]
# del res["2015년"]
# del res["2016년"]


# data_result.head()


# In[104]:


res


# In[61]:


# '구별' 정보를 index로 설정하세요.  set_index() 함수를 사용하여, inplace=true 옵션을 주세요. 

res.set_index(['구별'], inplace = True) # '구별' data를 key값화 시킴
res


# In[66]:


# np.corrcoef(첫번째컬럼, 두번째컬럼)함수를 이용하여   '고령자비율'과 '소계' 컬럼의 상관계수를 구하세요. 

senior_ratio = np.array(res['고령자비율'])
sub_total = np.array(res['소계'])

corr_with_senior=np.corrcoef(senior_ratio, sub_total)
corr_with_senior


# In[68]:


#np.corrcoef() 함수를 이용하여 '외국인비율'과 '소계' 컬럼의 상관계수를 구하세요. 

foreign_ratio = np.array(res['외국인비율'])
sub_total = np.array(res['소계'])


corr_with_foreign=np.corrcoef(foreign_ratio, sub_total)
corr_with_foreign


# In[69]:


#np.corrcoef() 함수를 이용하여 '인구수'와 '소계' 컬럼의 상관계수를 구하세요. 
pop= np.array(res['인구수'])
sub_total = np.array(res['소계'])


corr_with_pop=np.corrcoef(pop, sub_total)
corr_with_pop


# In[71]:


#data_result 데이터의 '소계' 로 내림차순 정렬하여 앞에서부터 5개만 보여주세요. 

res.sort_values(['소계'], ascending = False).head(5)


# In[111]:


#data_result 데이터의 '인구수'로 내림차순 정렬하여 앞에서부터 5개만 보여주세요. 

res.sort_values(['인구수'], ascending = False).head(5)
#res['소계'].sort_values() # return type: series


# # 8. CCTV와 인구현황 그래프로 분석하기

# In[74]:


import platform

from matplotlib import font_manager, rc
plt.rcParams['axes.unicode_minus'] = False

if platform.system() == 'Darwin':
    rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=path).get_name()
    rc('font', family=font_name)
else:
    print('Unknown system!!') 


# In[76]:


data_result = res
data_result.head()


# In[79]:


# data_result의 '소계'를 plot하세요. kind='barh', grid=True, figsize=(10,10), 색은 신경쓰지 말것


plt.figure(figsize=(10,10))
x = data_result['소계']  # type: series
x.plot(kind = 'barh', grid = True)

plt.show()


# In[83]:


# data_result의 '소계' 정보를 이용하여 정렬한후 barh 를 이용한 그래프를 그리세요. 

plt.figure(figsize=(10,10))
data_result.sort_values(['소계'], ascending = True, inplace = True)
x = data_result['소계']
x.sort_values( )
x.plot(kind = 'barh', grid = True)

plt.show()



# In[86]:


# data_result의 'CCTV비율' 컬럼 = 소계 컬럼 / 인구수 * 100 으로 연산 

data_result['CCTV비율'] = data_result['소계']/data_result['인구수'] *100



plt.figure(figsize=(10,10))
data_result.sort_values(['CCTV비율'], ascending = True, inplace = True)
x = data_result['CCTV비율']
x.sort_values( )
x.plot(kind = 'barh', grid = True)

plt.show()

# 'CCTV비율' 로 정렬하여 barh 그래프를 그리세요. 




# In[113]:


#  scatter 함수로 data_result의 '인구수'와 '소계' 로 ploting 하세요. 
# xlable : 인구수, ylabel CCTV
#scatter
plt.figure(figsize=(6,6))
x = np.array(data_result['인구수'])
y = np.array(data_result['소계'])
plt.scatter(x,y, c = 'b')

plt.xlabel('인구수')
plt.ylabel('CCTV')
plt.show()


#plt.scatter(data_result['인구수'],data_result['소계'], s=50)# 도 가능
#type(data_result['인구수'])


# In[96]:


#회귀 직선을 그리기 위한 기울기와 절편 구하기

fp1 = np.polyfit(data_result['인구수'], data_result['소계'], 1)
fp1


# In[114]:


#다항식 곡선피팅 
f1 = np.poly1d(fp1)
fx = np.linspace(100000, 700000, 100)


# In[122]:


# scatter 함수를 사용하여, data_result의 인구수와 소계 ploting 하세요.
#  scatter를  그린후 그 위에 직선을 그린다.
#  - 직선은 plt.plot(fx, f1(fx), ls='dashed', lw=3, color='g')를 참조하여 그릴것
#plt.plot(fx, f1(fx), ls='dashed', lw=3, color='g')


plt.figure(figsize=(7,7))
plt.scatter(data_result['인구수'],data_result['소계'], s=50)
plt.plot(fx,f1(fx),ls='dashed', lw=3, color='g')
plt.xlabel('인구수')
plt.ylabel('소계')
plt.show()




# # 10. 조금더 설득력 있는 자료 만들기

# In[131]:


fp1 = np.polyfit(data_result['인구수'], data_result['소계'], 1)

f1 = np.poly1d(fp1)
fx = np.linspace(100000, 700000, 100)

data_result['오차'] = np.abs(data_result['소계'] - f1(data_result['인구수']))

df_sort = data_result.sort_values(by='오차', ascending=False)
df_sort.head()


#df_sort['인구수']     type : series
#df_sort['인구수'][9]   type  value 
#type(df_sort.index)    type index
#df_sort.index


# In[44]:


plt.figure(figsize=(14,10))

# data_result의  '인구수'와 '소계를 이용하여 scatter plotting을 하세요. 컬러는 '오차'컬럼으로 정하세요. 

plt.scatter(data_result['인구수'], data_result['소계'], 
            c=data_result['오차'], s=50)
plt.plot(fx, f1(fx), ls='dashed', lw=3, color='g')

for n in range(10):
    plt.text(df_sort['인구수'][n]*1.02, df_sort['소계'][n]*0.98, 
             df_sort.index[n], fontsize=15)                # plt.text ( x좌표, y 좌표 ,'text')
    
plt.xlabel('인구수')
plt.ylabel('인구당비율')
plt.colorbar()
plt.grid()
plt.show()


# * 서울시에서 다른 구와 비교했을 때, 강남구, 양천구, 서초구, 은평구는 CCTV가 많지만,
# * 송파구, 강서구, 도봉구, 마포구는 다른 구에 비해 CCTV 비율이 낮다

# In[ ]:




