#!/usr/bin/env python
# coding: utf-8

# In[33]:


import numpy as np
import pandas as pd
from pandas import Series, DataFrame
import matplotlib.pyplot as plt


# In[34]:


#해당 파일을 읽어 df를 생성하세요


data = pd.read_csv('../data/tips1.csv')

data


# In[35]:


#tipdf의 차원을 조회하세요
np.ndim(data)


# In[36]:


#tipdf의 크기를 조회하세요(행, 열)
data.shape
data.columns
data['day'].unique()
data['day'].value_counts()
data['day'].value_counts().plot(kind='bar') #barh
plt.show()


# In[37]:


#맨 마지막 데이터 3개을 조회하세요
data.tail(3)


# In[38]:


#df의 정보를 조회하세요
data.info


# In[39]:


#가장 팁이 높은 데이터 3개의 정보를 구하세요
sub1= data.sort_values('tip',ascending=False)
sub1.head(3)


# In[40]:


#tips_pct를 구해서 tipdf에 새로운 컬럼명으로 추가하세요

A = data['total_bill']
B = data['tip']
C = (B/A)*100

data['pct']=C
data


# In[41]:


#성별, 팁비율별로 정렬하여 팁 비율이 높은 정보 3개 출력
sub2= data.sort_values(by=['sex','pct'],ascending=False).head(3)
sub2


# In[42]:


#male 정보를 따로 분리해서 크기 정보 조회
sub_m = data[data['sex']=='Male']
np.shape(sub_m)


# In[43]:


#Female 정보를 따로 분리해서 크기 정보 조회


# In[44]:


#각 row별 na값 갯수 count
temp =data.isna().sum(axis=1)
print(temp[244])


# In[31]:


#na값 포함된 row 삭제
data.dropna()  # 반영은 안된상태
data.dropna(inplace =True)


# In[24]:


data


# In[45]:


data_pct_ser=data['pct']
data_pct_ser.plot(kind='hist',bins=60)
plt.show()


# In[46]:


data_pct_ser.describe()


# In[47]:


data_pct_ser.quantile([0.25,0.5,0.75,0.9,0.95])  #series


# In[ ]:




