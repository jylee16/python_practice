#!/usr/bin/env python
# coding: utf-8

# In[1]:


class test:
    a =3    ## static 
    def __init__(self):
        b = 4  ## instance 생성시 
        print('generate')
    
    


# In[2]:


print(test.a)


# In[5]:


ins = test


# In[6]:


print(a)


# In[7]:


print(ins.a)


# In[6]:


import numpy as np
import pandas as pd
from pandas import Series, DataFrame
import matplotlib.pyplot as plt
import seaborn as sns

arr1 = np.array([[1,2,3],[4,5,6],[7,8,9]])
arr2 = np.array([True,False])

print(arr1.dtype, arr2.dtype)

arr3 =arr2.astype(np.int64)
arr3


# In[7]:


arr4= np.random.randint(1,20,9).reshape(3,3)


# In[8]:


print(arr4)


# In[20]:


arr5= np.random.randint(-5,5,9).reshape(3,3)


# In[21]:


print(arr5)


# In[22]:



arr5[arr5<0] = -100


# In[23]:


print(arr5)


# In[24]:


get_ipython().run_line_magic('pinfo', 'np.where')


# In[25]:


res = np.where(arr5<0, 0,arr5)


# In[26]:


print(res)


# In[27]:


arr6 = np.random.randint(1,20,16).reshape(4,4)


# In[28]:


np.sum(arr6)


# In[ ]:




