#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import pandas as pd
from pandas import Series, DataFrame
import matplotlib.pyplot as plt
import seaborn as sns


# In[4]:


df1 = DataFrame(np.random.randn(4,4),columns =list('ABCD'))

df1


# In[10]:


df1.apply( lambda x:x.max()+x.min()  )

def test(a):
    return a**2

df1.apply( lambda x:x.max()+x.min()  )
df1.apply( lambda x: x**2 )
df1.apply( test )



# In[11]:


# http://www.leejungmin.org/post/2018/04/21/pandas_apply_and_map/ ,   apply , applymap 차이

tFormat = lambda x: '%.2f' %x  ## 문자열

df1.applymap(tFormat)


# In[17]:


df2 = DataFrame(np.random.randint(4,15,20).reshape(5,4), columns=['ko','eng','math','sci'])
df2['name']=['kim','park','choi','kim','park']


# In[18]:


df2


# In[20]:


df2.groupby('name').mean()


# In[22]:


df2.groupby('name').sum()


# In[23]:


df2['class'] = [1,1,1,2,2]


# In[24]:


df2


# In[25]:


df2.groupby(['class','name']).mean()


# tip 연습

# In[35]:


tipdf = sns.load_dataset('tips')


# In[41]:


tipdf['tip_pct'] = tipdf['tip']/tipdf['total_bill']*100

tipdf.head(3)


# In[48]:


#group 기준 성별, 흡연자별 팁의 평균, 전체평균, 팁비율 평균
tipdf.groupby(['sex']).mean()  # 숫자데이터만 계산


# In[ ]:





# In[47]:


tipdf_gr = tipdf.groupby(['sex','smoker'])
tipdf_gr   # <pandas.core.groupby.groupby.DataFrameGroupBy object at 0x000000000B81DA90> # dataframe


# In[49]:


tipdf_gr['tip_pct'] #<pandas.core.groupby.groupby.SeriesGroupBy object at 0x00000000098DA588>  # series


# In[54]:


tipdf_gr['tip_pct'].agg(['mean','sum','std'])   #agg 집계함수


# In[57]:


# tipdf를 성별, 흡연자별 각종 데이터를 그룹핑
tipdf.pivot_table(index = ['sex','smoker'])


# In[62]:


#tipdf에 있는 데이터 중에서 total_bill, tip 에 대해서 그룸핑(성별, 날짜)
tip_pv = tipdf.pivot_table(values=['total_bill', 'tip'],index = ['sex','day'], columns = 'smoker')
tip_pv


# In[65]:


type(tip_pv) #pandas.core.frame.DataFrame

tip_pv.iloc[:, 0:3]


# In[66]:


tip_pv = tipdf.pivot_table(values=['total_bill', 'tip'],index = ['sex','day'], columns = 'smoker', margins =True)  # aggfunc= np.mean
tip_pv


# In[67]:


tip_pv = tipdf.pivot_table(values=['total_bill', 'tip'],index = ['sex','day'], columns = 'smoker', margins =True, aggfunc= sum)
tip_pv


# In[78]:


#식당에 방문하는 고객의 그룹핑 기준: 성별, 흡연자별
#날짜별로 방문 빈도수를 계산해서 표출하세요 총합도 같이 계산하세요
# 데이터는 tip_pct 사용  len 갯수  values = 'total_bill' 로 바꿔도 결과 같음
tip_pv = tipdf.pivot_table(values=['tip_pct'], index = ['sex','smoker'], 
                           columns=['day'], aggfunc = len, margins=True)
tip_pv


# In[ ]:





# In[37]:


iris = sns.load_dataset('iris')


# In[38]:


iris


# In[ ]:




