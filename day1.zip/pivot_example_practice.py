#!/usr/bin/env python
# coding: utf-8

# In[1]:


#openpyxl, xlrd 설치 필요 
import pandas as pd 
import numpy as np 


# In[2]:


df = pd.read_excel("../data/02. sales-funnel.xlsx")


# In[3]:


df


# In[21]:


# 피벗 기능을 이용하여 아래 자료를 표현하세요.
#df_pv = df.pivot_table(index = ['Name']) # 수자값 모두표시
df_pv = df.pivot_table(index = ['Name'], values=['Account'])
df_pv


# In[11]:


# 피벗 기능을 이용하여 아래 자료를 표현하세요.
df_pv = df.pivot_table(index = ['Name','Rep','Manager'])
df_pv


# In[16]:


# 피벗 기능을 이용하여 아래 자료를 표현하세요. (기본적인 값은 price가 평균값으로 계산됩니다)
df_pv = df.pivot_table(values=['Price'], index = ['Manager','Rep']) 
df_pv    
    


# In[17]:


# 피벗 기능을 이용하여 아래 자료를 표현하세요. aggfunc=np.sum 옵션을 주면 price값이 합산으로 표현됩니다.
df_pv = df.pivot_table(values=['Price'], index = ['Manager','Rep'], aggfunc=np.sum ) 
df_pv   


# In[20]:


# 피벗 기능을 이용하여 아래 자료를 표현하세요.margins=True 옵션을 주면, 아래 총합정보가 표현됩니다.
df_pv = df.pivot_table(values=['Price','Quantity'], index = ['Manager','Rep', 'Product'], aggfunc=[np.sum, np.mean] , margins = True) #margin =all출력

df_pv   


# In[ ]:




