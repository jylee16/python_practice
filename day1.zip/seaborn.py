#!/usr/bin/env python
# coding: utf-8

# In[6]:


import numpy as np
import pandas as pd
from pandas import Series, DataFrame
import matplotlib.pyplot as plt
import seaborn as sns
import platform


# In[7]:



flights =sns.load_dataset('flights')


# In[22]:



pvflights = flights.pivot_table(values = 'passengers', index = ['month'], columns = 'year')
pvflights

type(pvflights) # dataframe 
plt.figure(figsize=(10,10))
sns.heatmap(pvflights, annot = False, fmt = 'd')  # annot 
plt.show()


# In[24]:


irisdf = sns.load_dataset('iris')
irisdf.head(3)
irisdf.shape


# In[26]:


sns.pairplot(irisdf,hue= 'species')
plt.show()


# In[27]:


sns.pairplot(irisdf,x_vars=['sepal_width', 'sepal_length'],y_vars=['petal_width','petal_length'], hue= 'species')
plt.show()


# In[29]:



tipdf =sns.load_dataset('tips')
tipdf.head()


# In[35]:


plt.figure(figsize  = (8,6))
sns.boxplot(x='day', y='total_bill', data=tipdf)
#sns.boxplot(x='day', y='total_bill', data=tipdf, hue='smoker') #smoker에 대해 분류하여 표시
sns.swarmplot(x='day', y='total_bill', data=tipdf, color = '.5')  #실제 data 표시
plt.show()


# In[ ]:




