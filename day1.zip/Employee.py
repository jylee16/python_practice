#!/usr/bin/env python
# coding: utf-8

# In[12]:


get_ipython().run_cell_magic('writefile', 'empModule.py', '\nclass Employee():\n    \n    def __init__(self, name, dep, payment ,W_hr_per_week):\n        self.name = name\n        self.dep = dep\n        self.payment = int(payment)\n        self.W_hr_per_week = int(W_hr_per_week)        \n        print(\'등록:\', self.name, self.dep,self.payment, self.W_hr_per_week)\n\n        \n   \n    #def __init__(self,info):    ## overloading\n    #    self.name, self,dep, self.pay, self.hour = info\n        \n    def __str__(self):\n        return self.name+\':\'+self.dep+\':\'+str(self.payment)+\':\'+str(self.W_hr_per_week)\n    \n    \n    def showEmpInfo(self):\n        print(self.__str__())\n    \n    def payForWeek(self):\n        payForHour = self.payment/(12*20*8)\n        wPay = self.W_hr_per_week*payForHour\n        if(40 >self.W_hr_per_week):\n            wPay = (self.W_hr_per_week-40)*(payForHour*1.5) + 40*payForHour       \n        return wPay\n    \n    def getName(self):\n        name = self.name\n        return name\n   \n    def setHours(self, W_hr_per_week):\n        self.W_hr_per_week = W_hr_per_week\n        print("주당근무시간:", W_hr_per_week,"시간 로 변경")\n        ')


# In[ ]:




