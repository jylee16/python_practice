#!/usr/bin/env python
# coding: utf-8

# # 시계열 데이터처리

# In[16]:


import numpy as np
import pandas as pd
from pandas import Series, DataFrame
import matplotlib.pyplot as plt
import seaborn as sns


data = np.random.randint(80,90,20).reshape(5,4)
idx_data = ['2017-02-03','2017-03-05','2018-05-06','2018-08-23','2019-04-04']
df3 = DataFrame(data, index=idx_data, columns =list('ABCD'))
df3


# In[17]:


A  = np.array(df3['A'])
print(A)
D = np.array(df3.iloc[2])
print(D)


# In[19]:


df3.index = pd.to_datetime(df3.index)  # type이 datetime으로 바뀜
df3.index


# In[22]:


df3.resample(rule='A').mean()   # A = 연도,  B = 월, C  = 날짜(workingday), Q = 분기별


# In[23]:


timeidx= pd.date_range('2017-01-01', periods = 1000)


# In[24]:


timeidx


# In[25]:


df4 = DataFrame(np.random.randn(1000,4), index = timeidx, columns = list('ABCD'))
df4


# In[31]:


df4.resample(rule='Y').mean()
df4.resample(rule='Y').mean().T


# In[34]:


type(df4.resample(rule='M'))  #pandas.core.resample.DatetimeIndexResampler
type(df4.resample(rule='M').mean()) #  pandas.core.frame.DataFrame


# In[39]:


df4.resample(rule='Q').mean()['A'].plot(kind='line', grid =True)
plt.show()


# In[41]:


df4.to_csv('time_series_data.csv')


# In[43]:


df4.to_excel('time_Series_data.xlsx', sheet_name = 'result')


# In[44]:


type(df4)


# In[ ]:




