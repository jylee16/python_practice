#!/usr/bin/env python
# coding: utf-8

# In[6]:


import numpy as np
import pandas as pd
from pandas import Series, DataFrame
import matplotlib.pyplot as plt
import seaborn as sns
import platform

from matplotlib import font_manager, rc
plt.rcParams['axes.unicode_minus'] = False

if platform.system() == 'Darwin':
    rc('font', family='AppleGothic')
elif platform.system() == 'Windows':
    path = "c:/Windows/Fonts/malgun.ttf"
    font_name = font_manager.FontProperties(fname=path).get_name()
    rc('font', family=font_name)
else:
    print('Unknown system!!') 


# In[8]:


# line 

plt.figure(figsize = (8,6))

x = [1,2,4,8]
y = [i**2 for i in x]
plt.plot(x,y)
plt.show()


# In[21]:


plt.figure(figsize = (6,4))
t = np.arange(0,12,0.01)
plt.plot(t,np.sin(t), label = 'sin')
plt.plot(t,np.cos(t), label = 'cos')
plt.grid()
plt.legend()
plt.xlabel('time')
plt.ylabel('amp')
plt.title('graph')
plt.show()


# In[24]:


#scatter
plt.figure(figsize=(6,4))
x = np.random.randint(1,10,10)
y = np.random.randint(1,10,10)
plt.scatter(x,y, c = 'r')
plt.show()


# In[26]:


#histogram
plt.figure(figsize = (6,4))
data = np.random.randn(500)
plt.hist(data, bins = 50, color = 'b', alpha=0.5)  # alpha = 투명도
plt.show()


# In[32]:


#boxplot
plt.figure(figsize = (6,4))
a = np.random.rand(1000)
b = np.random.rand(1000)
c = np.random.rand(1000)
plt.boxplot([a,b,c])
plt.show()


# In[40]:


plt.figure(figsize = (9,3))
plt.subplot(131) # 1행 3열 1번째
data = np.random.randn(500)
plt.hist(data, bins = 60, color = 'b', alpha = 0.2)
plt.subplot(132)
x = np.random.randint(1,10,10)
y = np.random.randint(1,10,10)
plt.scatter(x,y, c = 'r')
plt.subplot(133)
a = np.random.rand(1000)
b = np.random.rand(1000)
c = np.random.rand(1000)
plt.boxplot([a,b,c])
plt.show()


# # pandas plot

# In[44]:


ts = pd.Series(np.random.randn(1000), index = pd.date_range('1/1/2000', periods = 1000))
ts = ts.cumsum()
ts
ts.plot()


# In[53]:


ts = pd.date_range('2010-01-01', periods =1000)
ser1 = Series(np.random.randn(1000), index = ts)
ser1 = ser1.cumsum()
ser1.plot(kind = 'line', grid = True) #kind = 'hist', bins = 40
plt.show()


# In[ ]:




