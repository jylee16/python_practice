
def call(num):
    print(num,'번호로 전화를 합니다.. ')



if __name__=='__main__': ## 단독실행시에만 실행
    call('1234564789')
