
class Employee():
    
    def __init__(self, name, dep, payment ,W_hr_per_week):
        self.name = name
        self.dep = dep
        self.payment = int(payment)
        self.W_hr_per_week = int(W_hr_per_week)        
        print('등록:', self.name, self.dep,self.payment, self.W_hr_per_week)

        
   
    #def __init__(self,info):    ## overloading
    #    self.name, self,dep, self.pay, self.hour = info
        
    def __str__(self):
        return self.name+':'+self.dep+':'+str(self.payment)+':'+str(self.W_hr_per_week)
    
    
    def showEmpInfo(self):
        print(self.__str__())
    
    def payForWeek(self):
        payForHour = self.payment/(12*20*8)
        wPay = self.W_hr_per_week*payForHour
        if(40 >self.W_hr_per_week):
            wPay = (self.W_hr_per_week-40)*(payForHour*1.5) + 40*payForHour       
        return wPay
    
    def getName(self):
        name = self.name
        return name
   
    def setHours(self, W_hr_per_week):
        self.W_hr_per_week = W_hr_per_week
        print("주당근무시간:", W_hr_per_week,"시간 로 변경")
        
