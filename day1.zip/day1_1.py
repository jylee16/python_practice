#!/usr/bin/env python
# coding: utf-8

# In[1]:


b = 300
c = 300
print(id(b))
print(id(c))


# In[18]:


b1 =255
c1 =255
print(id(b1))
print(id(c1))


# In[37]:


inputdata = input("input:")
time =int(inputdata)
print( int(time/3600),"시" ,int((time%3600)/60),"분",int((time%3600)%60),"초" ) 


# In[ ]:





# In[ ]:




