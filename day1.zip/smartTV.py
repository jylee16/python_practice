#!/usr/bin/env python
# coding: utf-8

# In[1]:




def playMovie(title):
    print(title,'영화를 상영 합니다.. ')

playMovie('돈')


# In[ ]:




