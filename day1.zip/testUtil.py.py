#!/usr/bin/env python
# coding: utf-8

# In[2]:


import util_mod

a = util_mod.CheckValue()
a.parenMatch('())')


# In[ ]:




