#!/usr/bin/env python
# coding: utf-8

# In[46]:




class Employee():

    def __init__(self, name, dep, payment ,W_hr_per_week):
        self.name = name
        self.dep = dep
        self.payment = int(payment)
        self.W_hr_per_week = int(W_hr_per_week)
        print('등록:', self.name, self.dep,self.payment, self.W_hr_per_week)
        #payForHour(payment)
   
    #def __init__(self,info):    ## overloading
    #    self.name, self,dep, self.pay, self.hour = info
        
    def __str__(self):
        return self.name+':'+self.dep+':'+str(self.payment)+':'+str(self.W_hr_per_week)
    
    
    def showEmpInfo(self):
        print(self.__str__())
    
    def payForWeek(self):
        payForHour = self.payment/(12*20*8)
        wPay = self.W_hr_per_week*payForHour
        if(40 >self.W_hr_per_week):
            wPay = (self.W_hr_per_week-40)*(payForHour*1.5) + 40*payForHour
            
        return wPay
    def payForWeek(self, aa):
        print('called')
        pass
        
    def setHours(self, W_hr_per_week):
        self.W_hr_per_week = W_hr_per_week
        print("주당근무시간:", W_hr_per_week,"시간 로 변경")
        


# In[47]:


person=[]
for idx in range(0,1):
    info= input('input(이름,부서,연봉,주당근무시간): ').split(',')   
    #info = [int(x) if x.isnumeric() else x for x in info]
    ins = Employee(info[0],info[1],info[2],info[3])
    ins.showEmpInfo()
    person.append(ins)


paysum =0


print(payForWeek('a'))
#for i in person:
#    paysum = paysum +i.payForWeek()

print('total:', paysum)

#person[0].showEmpInfo


# In[ ]:




