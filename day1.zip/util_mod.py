
class CheckValue():
    
    
    
    def __init__(self):
        
        print('called:')
        
    def checkVowel(self, str):
        print('checkVowel')
        result = False
        for item in str:
            if item.islower():
                if item in set(['a','e','i','o','u']):
                    result = True
                    break
        return result
        
    
    def parenMatch(self, str):
        print('parenMatch')
        open_=str.count("(")
        close_=str.count(")")
        print( "(개수:",open_,  ")개수:", close_)
        if open_==close_:
            return True
        else:
            return False
        

