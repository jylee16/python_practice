#!/usr/bin/env python
# coding: utf-8

# # 계단오르내리기 예제

# In[58]:


import numpy as np 
import matplotlib.pyplot as plt
np.random.seed(888)


# In[67]:


nsteps = 1000 

# randint 함수를 사용하여 1000개의 랜덤값을 만드세요.
draws= np.random.randint(0,2,nsteps)

#draws

steps = np.where(draws>0, 1,-1)
walk = np.cumsum(steps)

print(np.min(walk))
print(np.max(walk))

# 계단의 처음 위치에서 10칸이상 떨어진 시점을 구하자.(np.abs함수 사용)
# 최초로 10 혹은 -10인 시점을 구해야하므로 boolean 배열에서 
# 최대값의 처음 색인을 반환하는 argmax() 함수 사용
k = (np.abs(walk)>=10).argmax()
print(steps)
#print(walk.shape)
print(walk)


# In[60]:


plt.figure(figsize = (10,6))
plt.plot(walk)
plt.show()


# In[ ]:




