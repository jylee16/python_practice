def playMovie(title):
    print(title,' 영화를 상영합니다...')
    
if __name__ == '__main__':
    playMovie('돈123456')
