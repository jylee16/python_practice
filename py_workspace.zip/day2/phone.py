def call(num):
    print(num,' 번호로 전화를 합니다...')
    
print('__name__ : ', __name__)
if __name__ == '__main__':    
    call('12345678')
