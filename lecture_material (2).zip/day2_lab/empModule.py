
class Employee:
    
    def __init__(self, name="", dept="", pay=0, hour=40):
        self.name = name
        self.dept = dept
        self.pay = pay
        self.hour = hour
        
    def __init__(self, empL):
        self.name, self.dept, self.pay, self.hour = empL
        
    def showEmpInfo(self):
        #pass
        print('직원정보', self.__str__())
        
    def __str__(self):
        return self.name+":"+self.dept+":"+str(self.pay)+":"+str(self.hour)
    
    def payForWeek(self):
        payPerH = self.pay / (12*20*8)
        wPay = self.hour * payPerH
        if(self.hour > 40):
            wPay = (self.hour-40)*payPerH*1.5 + 40*payPerH
        return wPay
    
    def setHors(self, h):
        self.hour = h
        
if __name__ == '__main__':
    dataL = ['Lee','Marketing', 5000000, 42]
    emp = Employee(dataL)
    emp.showEmpInfo()
